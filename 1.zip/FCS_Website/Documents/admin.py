from django.contrib import admin

from Documents.models import Document


admin.site.register (Document)

# Register your models here.
