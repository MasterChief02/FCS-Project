from django.db import models


class Wallet (models.Model):
  pass